// JavaScript Document

$(document).ready(function(){
	$("#banner").owlCarousel({
		items:1,
		autoplay:true,
		smartSpeed:2000,
		loop:true,
		nav:true,
		dots: false
	})
	

$("#danhmuc").owlCarousel({
	smartSpeed:1000,
	loop: true,
	autoplay: true,
	items: 3,
	margin: 30,
	nav: true,
	autoplayTimeout: 1000
	
	
	
})
})